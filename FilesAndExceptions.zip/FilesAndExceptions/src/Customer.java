import java.io.*;
import java.util.List;
import java.util.StringTokenizer;
import java.util.ArrayList;
import java.util.Scanner;

public class Customer {
    public static void main(String[] args) {
        ArrayList<Account> accountsList = new ArrayList<Account>();

        BufferedReader reader;

        try {
            reader = new BufferedReader(new FileReader
                    ("accounts.dat"));
            String line = reader.readLine();
            while (line != null) {
//                System.out.println(line);

                String[] accInfo = line.split(":");

//                System.out.println(accInfo[0]);

                int accNumber = Integer.parseInt(accInfo[0]);
                String userName = accInfo[1];
                double balance = Double.parseDouble(accInfo[2]);

                Account act = new Account(accNumber, userName,
                        balance);
                accountsList.add(act);

                //  Read next line
                line = reader.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        //  Take account number from user
        while (true) {

            Scanner input = new Scanner(System.in);

            System.out.print("Enter account number: ");

            if(input.hasNextInt()){

                int accNumber = input.nextInt();

                System.out.println(accNumber);

                System.out.println("Valid Account");

                int index = findIndex(accountsList, accNumber);

                System.out.println(index);

            } else {
                System.out.println("Invalid Account");
            }

        }
    }

    public static int findIndex(ArrayList<Account> accountList,
                                int accountNumber) {
        System.out.println("Find info for account: " +
                accountNumber);

        int index = -1;

        for (int i = 0; i < accountList.size(); i++) {
            Account act = accountList.get(i);
            if (act.getAcctNumber() == accountNumber) {
                index = i;
                break;
            }
        }
        return index;
    }

}
