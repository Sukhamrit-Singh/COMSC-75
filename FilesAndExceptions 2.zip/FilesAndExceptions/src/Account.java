class Account {
    private int acctNumber;
    private String name;
    private double balance;

    public Account(int acct_number, String name, double balance) {
        this.acctNumber = acct_number;
        this.name = name;
        this.balance = balance;
    }

    public int getAcctNumber() {
        return acctNumber;
    }

    public String getName() {
        return name;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String toString() {
        return acctNumber + ": " +
                name + ": " +
                balance;
    }

    //  Method to deposit amounts of money
    void deposit(double amount) {
        if ( amount < 0 ) {
            // do nothing

        } else {
            // change the balance
            balance += amount;
        }
    }

    //  Method to withdraw amounts of money
    void withdraw(double amount) {
        if ( amount < 0 ) {
            // do nothing

        } else {

            if ( amount > balance ) {
                // do nothing
            } else {
                // change the balance
                balance -= amount;
            }
        }
    }

}
